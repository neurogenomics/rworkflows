## ---- echo=FALSE, include=FALSE-----------------------------------------------
pkg <- read.dcf("../DESCRIPTION", fields = "Package")[1]
library(pkg, character.only = TRUE)

## ----Session Info-------------------------------------------------------------
utils::sessionInfo()

